// quando rodar esse script no navegador se colcoar so app tem acesso ao dropbox
window.app = new DropBoxController();