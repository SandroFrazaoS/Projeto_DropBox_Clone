var express = require('express');
var router = express.Router();
var formidable = require('formidable');
var fs = require('fs');       // fs mexe com filesystem

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});


router.get('/file', (req, res) =>{

    let path = './' + req.query.path;  //pegar o caminho via query string - patha é o nome do caminho - file?path

    if(fs.existsSync(path)) {

        fs.readFile(path, (err, data)=> {

            if (err) {

              console.error(err);
              res.status(400).json({
                error: err
              });

            } else {

              res.status(200).end(data);

            }

        });

    } else {

      res.status(404).json({
        error:'file not found.'
      });    

    }

});

router.delete('/file', (req, res) =>{
 
  let form = new formidable.IncomingForm({
    uploadDir: './upload',
    keepExtensions: true
  });

    form.parse(req, (err, fields, files)=>{

      let path = "./" + fields.path;  //file.path é o caminho

      if(fs.existsSync(path)){  // verificar se fs exist 

        fs.unlink(path, err=>{    //unlink remove arquivo - passa o path do caminho

            if(err) {  // se der erro de 400 a 499 sao erros ma solicitação, passou algo que nao existe
              res.status(400).json({
                err
              });
            } else {

              res.json({ // se deu certo responde com os dados do arquivo excluido
                fields    
              });
       
            }

        });

      } else {
        res.status(404).json({
          error:'file not found.'
        });    
  
      }

    });

});

router.post('/upload', (req, res) => {
//                          metodo dele - recuperando formulario
  let form = new formidable.IncomingForm({
    uploadDir: './upload',
    keepExtensions: true
  })

  // intepreta os dados que estao vindo, req os dados que fora enviados
  form.parse(req, (err, fields, files)=>{

  //req.body sao os dados
  //res.json(req.body);

    res.json({
      //files: files
      files    
    });


  });


});


module.exports = router;
